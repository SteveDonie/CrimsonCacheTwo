namespace CrimsonCacheTwo
{
	public interface IEjectCacheEntries
	{
		CacheEntry GetEjectionVictim();
	}
}