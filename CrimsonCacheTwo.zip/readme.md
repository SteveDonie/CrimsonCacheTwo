CrimsonCacheTwo
===============

This is a Visual Studio 2010 solution that contains classes and tests that an in-memory cache with two different plug-in cache removal techniques.
